global.Elkaisar = {};
Elkaisar.CONST = {};
Elkaisar.CONST.BASE_URL   = "/Elkaisar";
Elkaisar.CONST.SERVER_ID  = 1;
Elkaisar.CONST.ServerPort = 8080;
Elkaisar.CONST.HOST = "localhost";
Elkaisar.CONST.DBName = "elkaisar";
Elkaisar.CONST.DBUserName = "root";
Elkaisar.CONST.DBPassWord = "";

require('./server');
