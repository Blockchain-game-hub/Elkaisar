global.Elkaisar = {};
Elkaisar.CONST = {};
Elkaisar.CONST.BASE_URL   = "";
Elkaisar.CONST.SERVER_ID  = 1;
Elkaisar.CONST.ServerPort = 8080;
Elkaisar.CONST.HOST = "app.elkaisar.com";
Elkaisar.CONST.DBName = "elkaisar_s_1__";
Elkaisar.CONST.DBUserName = "elkaisar_game";
Elkaisar.CONST.DBPassWord = "MyWifeSoma1231";

require('./server');
