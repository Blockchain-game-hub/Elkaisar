global.Elkaisar = {};
Elkaisar.CONST = {};
Elkaisar.CONST.BASE_URL   = "";
Elkaisar.CONST.SERVER_ID  = 2;
Elkaisar.CONST.ServerPort = 8081;
Elkaisar.CONST.HOST = "app.elkaisar.com";
Elkaisar.CONST.DBName = "elkaisar_s_2";
Elkaisar.CONST.DBUserName = "elkaisar_game";
Elkaisar.CONST.DBPassWord = "MyWifeSoma1231";

require('./server');